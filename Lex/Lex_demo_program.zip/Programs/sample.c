/*
 * sample source code
 */

main()	/* main program */
{
	int a,b,c;
	
	/* do some arithmetic */
	a = b + c; /* this should be
		initialized, but it's just an example */
}
